def sumar(numero1, numero2):
    print("El resultado de la suma es: ", numero1 + numero2)


def restar(numero1, numero2):
    print("El resultado de la suma es: ", numero1 - numero2)


def multiplicar(numero1, numero2):
    print("El resultado de la suma es: ", numero1 * numero2)


def dividir(numero1, numero2):
    print("El resultado de la suma es: ", numero1 / numero2)
