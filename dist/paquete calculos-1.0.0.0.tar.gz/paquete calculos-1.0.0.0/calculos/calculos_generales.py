def sumar(numero1, numero2):
    print("El resultado de la suma es: ", numero1 + numero2)


def restar(numero1, numero2):
    print("El resultado de la suma es: ", numero1 - numero2)


def multiplicar(numero1, numero2):
    print("El resultado de la suma es: ", numero1 * numero2)


def dividir(numero1, numero2):
    print("El resultado de la suma es: ", numero1 / numero2)


def potencia(base, exponente):
    print("El resultado de la operacion es: ", base**exponente)


def redondear(numero):
    print("El resultado de la operacion es: ", round(numero))
