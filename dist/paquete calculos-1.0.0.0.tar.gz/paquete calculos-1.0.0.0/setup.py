from setuptools import setup
setup(
    name="paquete calculos", version="1.0.0.0",
    description="Funciones basicas para ejemplo de paquetes distribles",
    author="Victor Hugo Tello Miramontes",
    author_email="victorhugotello@hotmail.com",
    packages=["calculos", "calculos.basicos"]
)
